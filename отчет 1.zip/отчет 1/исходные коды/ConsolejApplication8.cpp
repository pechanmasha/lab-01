﻿#include <iostream>
#include <bitset>

int main() {
    char x;
     x = -25;
    std::cout << std::bitset<8>(x) << std::endl;
     x = -1;
    std::cout << std::bitset<8>(x) << std::endl;
     x = -8;
    std::cout << std::bitset<8>(x) << std::endl;
}

