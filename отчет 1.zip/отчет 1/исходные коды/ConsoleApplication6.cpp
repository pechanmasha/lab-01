﻿// ConsoleApplication6.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <bitset>

int main() {
    int x;
    std::cin >> x;
    std::cout << "двоичное:" << std::bitset<16>(x) << std::endl;
    std::cout << "шестнадцатиричное:" << std::hex << x << std ::endl; 
    system("pause");
}

