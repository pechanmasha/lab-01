﻿// ConsoleApplication8.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include<bitset>

int main() {
    int x = 2147483647;
    std::cout << "число:" << x << std::endl;
    std::cout << "биты числа:" << std::bitset<32>(x) << std::endl;
    x = x + 1;
    std::cout << "результат в числах :" << x << std::endl;
    std::cout << "результат в битах:" << std::bitset<32>(x) << std::endl;
    system("pause");
}

