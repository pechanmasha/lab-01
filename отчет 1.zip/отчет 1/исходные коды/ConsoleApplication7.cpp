﻿// ConsoleApplication7.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>

int main() {
char a = 'a';
char b = 'b';
char c = 'c';
char d = 'd';
char e = 'e';
std::cout << "символ|ascii" << std::endl;
std::cout << "------|------" << std::endl;
std::cout << "     " << a << "|" << (int)a << std::endl;
std::cout << "     " << b << "|" << (int)b << std::endl;
std::cout << "     " << c << "|" << (int)c << std::endl;
std::cout << "     " << d << "|" << (int)d << std::endl;
std::cout << "     " << e << "|" << (int)e << std::endl;
system("pause");
}

